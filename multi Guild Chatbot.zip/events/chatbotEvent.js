const client = require("../index");
const { MessageEmbed, Collection } = require("discord.js")
const f = require("axios")
const model = require("../models/chatchannel")

client.on("messageCreate", async (message) => {
    if(!message.guild || message.author.bot) return;
    //if(message.channel.id == '947186451420938250') console.log(`${message.author.tag}  >>  ${message.content}`)

    let x = encodeURI(message.content)

    model.findOne({ Guild: message.guild.id }, async(err, data) => {
      if(!data) return
      if(message.channel.id != data.Channel) return
      if(message.content == '') x = 'no%20content'
      await message.channel.sendTyping();

      let data2 = await f(`https://fun-random-api.lol/chatbot/turbo?key=API_KEY_HERE&text=${x}`)
      let json = await data2.data.reply

      await message.channel.sendTyping();
      return message.reply({ content: `${json}` })
    })
});
