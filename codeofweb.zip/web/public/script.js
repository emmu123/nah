// Loading section

setTimeout(() => {
  document.querySelector('#loading_wrapper').style.display = 'none';
}, 1000);